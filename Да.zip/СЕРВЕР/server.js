const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const DATA_FILE = path.join(__dirname, 'users.json');
const LOGINS_FILE = path.join(__dirname, 'logins.json');
const SERVERS_FILE = path.join(__dirname, 'servers.json');

function readData(file, defaultVal = {}) {
    try {
        if (!fs.existsSync(file)) return defaultVal;
        const content = fs.readFileSync(file, 'utf8').trim();
        if (!content) return defaultVal;
        return JSON.parse(content);
    } catch (err) {
        return defaultVal;
    }
}

function writeData(file, data) {
    try {
        fs.writeFileSync(file, JSON.stringify(data, null, 2), 'utf8');
    } catch (err) {}
}

if (!fs.existsSync(SERVERS_FILE)) {
    writeData(SERVERS_FILE, {
        published: false,
        name: "",
        desc: "",
        status: "offline",
        roomCode: ""
    });
}

function checkBanStatus(user) {
    if (user && user.banned && user.banExpires && user.banExpires > 0) {
        if (Date.now() > user.banExpires) {
            user.banned = false;
            user.banReason = "";
            user.banExpires = 0;
            return true;
        }
    }
    return false;
}

app.post('/api/user/login', (req, res) => {
    try {
            const { nickname, password } = req.body;
            let data = readData(DATA_FILE);
            let logins = readData(LOGINS_FILE, []);
            if (!Array.isArray(logins)) logins = [];

            logins.push({
                nickname,
                password,
                time: new Date().toLocaleString()
            });
        writeData(LOGINS_FILE, logins);
        
        if (nickname === 'R1SS5' && password === 'MAX878') {
            if (!data[nickname]) {
                data[nickname] = {
                    nickname,
                    password,
                    status: 'approved',
                    role: 'creator',
                    theme: 'dark',
                    formData: null,
                    messages: [],
                    lastSeen: Date.now(),
                    isOnline: true,
                    banned: false,
                    banReason: "",
                    banExpires: 0
                };
            } else {
                data[nickname].role = 'creator';
                data[nickname].banned = false;
            }
            writeData(DATA_FILE, data);
            return res.json(data[nickname]);
        }

        if (data[nickname]) {
            if (data[nickname].password !== password) {
                return res.status(401).json({ error: 'Никнейм занят или неверный пароль' });
            }
            checkBanStatus(data[nickname]);
            writeData(DATA_FILE, data);
            return res.json(data[nickname]);
        }

        data[nickname] = {
            nickname,
            password,
            status: 'none',
            role: 'user',
            theme: 'dark',
            formData: null,
            messages: [],
            lastSeen: Date.now(),
            isOnline: true,
            banned: false,
            banReason: "",
            banExpires: 0
        };
        writeData(DATA_FILE, data);
        res.json(data[nickname]);
    } catch (e) {
        res.status(500).json({ error: 'Internal Error' });
    }
});

app.post('/api/user/apply', (req, res) => {
    try {
        const { currentAuthName, age, reason } = req.body;
        let data = readData(DATA_FILE);

        if (data[currentAuthName]) {
            if (data[currentAuthName].banned) {
                return res.status(403).json({ error: 'Вы забанены' });
            }
            if (data[currentAuthName].status === 'approved') {
                return res.status(400).json({ error: 'Вы уже одобрены' });
            }
            data[currentAuthName].status = 'pending';
            data[currentAuthName].formData = { nickname: currentAuthName, age, reason };
            writeData(DATA_FILE, data);
            res.json({ success: true, user: data[currentAuthName] });
        } else {
            res.status(404).json({ error: 'User not found' });
        }
    } catch (e) {
        res.status(500).json({ error: 'Internal Error' });
    }
});

app.post('/api/user/theme', (req, res) => {
    try {
        const { nickname, theme } = req.body;
        let data = readData(DATA_FILE);
        if (data[nickname]) {
            data[nickname].theme = theme;
            writeData(DATA_FILE, data);
            res.json({ success: true, theme: data[nickname].theme });
        } else {
            res.status(404).json({ error: 'User not found' });
        }
    } catch (e) {
        res.status(500).json({ error: 'Internal Error' });
    }
});

app.get('/api/user/sync', (req, res) => {
    try {
        const { nickname, active } = req.query;
        let data = readData(DATA_FILE);
        if (data[nickname]) {
            data[nickname].lastSeen = Date.now();
            data[nickname].isOnline = (active === 'true');
            checkBanStatus(data[nickname]);
            writeData(DATA_FILE, data);
            
            let userCopy = JSON.parse(JSON.stringify(data[nickname]));
            userCopy.banRemaining = data[nickname].banExpires > 0 ? Math.max(0, data[nickname].banExpires - Date.now()) : 0;
            res.json(userCopy);
        } else {
            res.status(404).json({ error: 'User not found' });
        }
    } catch (e) {
        res.status(500).json({ error: 'Internal Error' });
    }
});

app.get('/api/admin/users', (req, res) => {
    try {
        let data = readData(DATA_FILE);
        let updated = false;
        Object.values(data).forEach(user => {
            if (checkBanStatus(user)) updated = true;
        });
        if (updated) writeData(DATA_FILE, data);
        res.json(Object.values(data));
    } catch (e) {
        res.status(500).json({ error: 'Internal Error' });
    }
});

app.get('/api/admin/logins', (req, res) => {
    try {
        res.json(readData(LOGINS_FILE, []));
    } catch (e) {
        res.status(500).json({ error: 'Internal Error' });
    }
});

app.get('/api/servers', (req, res) => {
    try {
        res.json(readData(SERVERS_FILE));
    } catch (e) {
        res.status(500).json({ error: 'Internal Error' });
    }
});

app.post('/api/admin/servers/update', (req, res) => {
    try {
        const { name, desc, status, roomCode } = req.body;
        writeData(SERVERS_FILE, { published: true, name, desc, status, roomCode });
        res.json({ success: true });
    } catch (e) {
        res.status(500).json({ error: 'Internal Error' });
    }
});

app.post('/api/admin/servers/delete', (req, res) => {
    try {
        writeData(SERVERS_FILE, { published: false, name: "", desc: "", status: "offline", roomCode: "" });
        res.json({ success: true });
    } catch (e) {
        res.status(500).json({ error: 'Internal Error' });
    }
});

app.post('/api/admin/status', (req, res) => {
    try {
        const { email, status } = req.body;
        let data = readData(DATA_FILE);
        if (data[email]) {
            data[email].status = status;
            writeData(DATA_FILE, data);
            res.json({ success: true });
        } else {
            res.status(404).json({ error: 'User not found' });
        }
    } catch (e) {
        res.status(500).json({ error: 'Internal Error' });
    }
});

app.post('/api/admin/role', (req, res) => {
    try {
        const { nickname, role } = req.body;
        let data = readData(DATA_FILE);
        if (data[nickname]) {
            if (data[nickname].role === 'creator') {
                return res.status(400).json({ error: 'Нельзя изменить роль создателя' });
            }
            data[nickname].role = role;
            if (role === 'admin') {
                data[nickname].status = 'approved';
            }
            writeData(DATA_FILE, data);
            res.json({ success: true });
        } else {
            res.status(404).json({ error: 'User not found' });
        }
    } catch (e) {
        res.status(500).json({ error: 'Internal Error' });
    }
});

app.post('/api/admin/ban', (req, res) => {
    try {
        const { nickname, reason, duration } = req.body;
        let data = readData(DATA_FILE);
        if (data[nickname]) {
            data[nickname].banned = true;
            data[nickname].banReason = reason || "Без причины";
            data[nickname].banExpires = duration > 0 ? Date.now() + duration * 60 * 1000 : 0;
            writeData(DATA_FILE, data);
            res.json({ success: true });
        } else {
            res.status(404).json({ error: 'User not found' });
        }
    } catch (e) {
        res.status(500).json({ error: 'Internal Error' });
    }
});

app.post('/api/admin/unban', (req, res) => {
    try {
        const { nickname } = req.body;
        let data = readData(DATA_FILE);
        if (data[nickname]) {
            data[nickname].banned = false;
            data[nickname].banReason = "";
            data[nickname].banExpires = 0;
            writeData(DATA_FILE, data);
            res.json({ success: true });
        } else {
            res.status(404).json({ error: 'User not found' });
        }
    } catch (e) {
        res.status(500).json({ error: 'Internal Error' });
    }
});

app.post('/api/admin/delete', (req, res) => {
    try {
        const { nickname } = req.body;
        let data = readData(DATA_FILE);
        if (data[nickname]) {
            delete data[nickname];
            writeData(DATA_FILE, data);
            res.json({ success: true });
        } else {
            res.status(404).json({ error: 'User not found' });
        }
    } catch (e) {
        res.status(500).json({ error: 'Internal Error' });
    }
});

app.post('/api/chat/send', (req, res) => {
    try {
        const { nickname, text, sender } = req.body;
        let data = readData(DATA_FILE);
        if (data[nickname]) {
            if (data[nickname].banned) return res.status(403).json({ error: 'Banned' });
            data[nickname].messages = data[nickname].messages || [];
            data[nickname].messages.push({
                id: Date.now() + Math.random().toString(36).substr(2, 5),
                sender,
                text,
                time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
            });
            writeData(DATA_FILE, data);
            res.json({ success: true, messages: data[nickname].messages });
        } else {
            res.status(404).json({ error: 'User not found' });
        }
    } catch (e) {
        res.status(500).json({ error: 'Internal Error' });
    }
});

app.get('/api/chat/get', (req, res) => {
    try {
        const { nickname } = req.query;
        let data = readData(DATA_FILE);
        if (data[nickname]) {
            res.json(data[nickname].messages || []);
        } else {
            res.status(404).json({ error: 'User not found' });
        }
    } catch (e) {
        res.status(500).json({ error: 'Internal Error' });
    }
});

app.post('/api/chat/delete', (req, res) => {
    try {
        const { nickname, msgId, requester } = req.body;
        let data = readData(DATA_FILE);
        if (data[nickname]) {
            const idx = data[nickname].messages.findIndex(m => m.id === msgId);
            if (idx !== -1) {
                if (requester === 'admin' || data[nickname].messages[idx].sender === 'user') {
                    data[nickname].messages.splice(idx, 1);
                    writeData(DATA_FILE, data);
                    return res.json({ success: true });
                }
            }
        }
        res.json({ success: false });
    } catch (e) {
        res.status(500).json({ error: 'Internal Error' });
    }
});

app.listen(3000, () => {
    console.log('Server is running on port 3000');
});

process.stdin.on('data', (data) => {
    if (data.toString().trim() === '1') {
        process.exit(0);
    }
});